# Raw to Rated

A Flask-based AI card grading web app.